# Changelog

All notable changes to `ReceiptPrinter` will be documented in this file.

## Version 1.1.0
- Added support for Laravel 7.10 and newer

## Version 1.0.2
- Added network print connector

## Version 1.0.0
- Initial commit
