# The license

Copyright (c) Charlie Anthony <charlie@usahakreatif.co.id>

...Add your license text here...